
# Symptom Checker Chatbot

This project is a simple symptom checker chatbot with a JavaScript frontend and a Python FastAPI backend.

## Setup and Running

### Backend

1.  **Navigate to the backend directory:**
    ```bash
    cd medbot/backend
    ```

2.  **Install the required dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

3.  **Train the model:**
    ```bash
    python model_train.py
    ```

4.  **Start the FastAPI server:**
    ```bash
    uvicorn app:app --reload
    ```

### Frontend

1.  **Navigate to the frontend directory:**
    ```bash
    cd medbot/frontend
    ```

2.  **Start a simple HTTP server:**
    ```bash
    python -m http.server 5173
    ```

3.  **Open your browser and go to `http://localhost:5173`**
