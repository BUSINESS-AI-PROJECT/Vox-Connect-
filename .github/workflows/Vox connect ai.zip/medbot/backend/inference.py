import pickle
import numpy as np

with open('model_artifacts.pkl', 'rb') as f:
    artifacts = pickle.load(f)

model = artifacts['model']
mlb = artifacts['mlb']
symptoms = artifacts['symptoms']
diseases = artifacts['diseases']

def preprocess_text(text):
    return text.lower().replace('[', '').replace(']', '').replace("'", "").replace('"', "").replace('.', '').replace(',', '').split()

def extract_symptoms(text):
    words = preprocess_text(text)
    return [symptom for symptom in symptoms if symptom in words]

def predict_disease(symptom_list):
    if not symptom_list:
        return []

    input_vector = mlb.transform([symptom_list])
    probabilities = model.predict_proba(input_vector)[0]

    top_3_indices = np.argsort(probabilities)[-3:][::-1]
    
    predictions = []
    for i in top_3_indices:
        predictions.append({
            "disease": diseases[i],
            "prob": probabilities[i]
        })
        
    return predictions
