
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import MultiLabelBinarizer
import pickle

# Load the dataset
df = pd.read_csv('dataset.csv')

# Drop duplicates
df.drop_duplicates(inplace=True)

# Identify symptom columns
symptom_cols = [col for col in df.columns if col.startswith('Symptom_')]

# Preprocessing
for col in symptom_cols:
    df[col] = df[col].str.lower().str.strip().fillna('missing')

# Get all unique symptoms
all_symptoms = set()
for col in symptom_cols:
    all_symptoms.update(df[col].unique())
all_symptoms.remove('missing')
all_symptoms = sorted(list(all_symptoms))

# One-hot encode symptoms
X = df[symptom_cols].apply(lambda x: ','.join(x), axis=1)
y = df['Disease']

mlb = MultiLabelBinarizer(classes=all_symptoms)
X_bin = mlb.fit_transform(X.str.split(','))

# Train the model
X_train, X_test, y_train, y_test = train_test_split(X_bin, y, test_size=0.2, random_state=42)

model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Validate the model
y_pred = model.predict(X_test)
print(f"Model Accuracy: {accuracy_score(y_test, y_pred)}")

# Save the model and artifacts
with open('model_artifacts.pkl', 'wb') as f:
    pickle.dump({
        'model': model,
        'mlb': mlb,
        'symptoms': all_symptoms,
        'diseases': model.classes_
    }, f)

print("Model training complete and artifacts saved to model_artifacts.pkl")
