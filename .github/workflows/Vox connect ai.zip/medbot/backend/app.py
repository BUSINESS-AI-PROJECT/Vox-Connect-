
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from inference import extract_symptoms, predict_disease, symptoms
import random

app = FastAPI()

# CORS setup
origins = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ChatMessage(BaseModel):
    message: str

class PredictPayload(BaseModel):
    symptoms: list[str]

@app.get("/health")
def health_check():
    return {"status": "ok"}

@app.get("/symptoms")
def get_symptoms():
    return {"symptoms": symptoms}

@app.post("/predict")
def predict(payload: PredictPayload):
    predictions = predict_disease(payload.symptoms)
    return {"predictions": predictions}

@app.post("/chat")
def chat(payload: ChatMessage):
    recognized_symptoms = extract_symptoms(payload.message)
    predictions = predict_disease(recognized_symptoms)

    if not recognized_symptoms:
        bot_message = "I didn't recognize some of those symptoms. Could you rephrase or add more?"
    else:
        if predictions:
            top_diseases = [p['disease'] for p in predictions[:2]]
            bot_message = f"Hmm... those symptoms might relate to {' or '.join(top_diseases)}. Are you also feeling tired or feverish?"
        else:
            bot_message = "I'm not sure based on those symptoms. Can you provide more details?"

    return {
        "bot_message": bot_message,
        "recognized_symptoms": recognized_symptoms,
        "predictions": predictions
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
